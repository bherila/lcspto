tinyMCE.addI18n('en.pdw',{
	desc : 'Show/hide toolbars'
});
